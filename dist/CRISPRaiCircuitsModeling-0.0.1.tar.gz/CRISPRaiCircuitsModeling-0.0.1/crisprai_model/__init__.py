"""__init__ file: initializer should contain all necessary information to run package
"""

# List the names of all modules used for working with package, version
__all__ = ["crisprai_model", "crisprai_model_test"]
__version__ = "1.0.0"
__name__ = "__main__"